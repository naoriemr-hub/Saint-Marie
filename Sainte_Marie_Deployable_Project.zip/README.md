# Dashboard Sainte-Marie

Déploiement:
- Ouvrir index.html ou déployer sur Netlify/Vercel/GitHub Pages.
- Application 100% statique.
